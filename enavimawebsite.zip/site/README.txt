ENAVIMA WEBSITE — congenital CMV
Built for Microgen Laboratories, August 2026

WHAT'S HERE
  index.html ............ Home
  congenital-cmv.html ... About congenital CMV (education hub)
  parents.html .......... For parents & expecting families
  clinicians.html ....... For clinicians
  labs.html ............. For hospitals & laboratories (+ evaluation request form)
  test.html ............. The Enavima point-of-care test
  about.html ............ About, team, collaborators, contact

HOW TO PUBLISH
  Every page is a single self-contained HTML file — all CSS and SVG are inline.
  There are no build steps, no images to upload, and no dependencies except
  Google Fonts, which loads from the web.

  Upload all seven .html files to the root of the web host (or drag the folder
  into Netlify Drop / Cloudflare Pages / GitHub Pages). index.html is the home
  page. That's it.

BEFORE IT GOES LIVE — please confirm these three things
  1. REGULATORY WORDING. The footer and test.html both state that Enavima assays
     are in development, are not available for sale, and are not FDA cleared or
     approved. Dr. Kommineni (QA/RA) should confirm this is the exact language
     Microgen wants to use.
  2. NO PERFORMANCE CLAIMS. No sensitivity, specificity or limit-of-detection
     figures appear anywhere; the site says these are available on request under
     confidentiality. Add real figures only once they are cleared for publication.
  3. THE CONTACT FORMS use mailto: links, which open the visitor's email client
     and do not always work. Before launch, swap them for a real form service
     (Formspree, Netlify Forms, or whatever the host provides).

SOURCES FOR EVERY STATISTIC
  CDC — About CMV and Congenital CMV Infection
  CDC — Clinical Overview of Congenital CMV Infection
  AAP — Congenital Cytomegalovirus (cCMV)
  Minnesota Dept. of Health — the Vivian Act, universal screening from 2023-02-06
  AAO-HNS — State cCMV Laws tracker (2 universal / 13 hearing-targeted / 8 education)
  Microgen Laboratories — microgenlabs.com (products, team, research)

  State screening laws change often. Re-check the AAO-HNS tracker before launch
  and every few months after.

TO EDIT LATER
  Each file is plain HTML with an inline <style> block. The style block is
  identical in all seven files, so a global design change means editing the
  same block in each — or ask Claude to regenerate the set from the source.
